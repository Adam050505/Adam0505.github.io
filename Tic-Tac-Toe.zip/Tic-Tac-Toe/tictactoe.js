const board_el = document.querySelector('#board');
const cell_els = document.querySelectorAll('#board .cell');
const combinations = [
    [0, 1, 2],
    [3, 4, 5],
    [6, 7, 8],
    [0, 3, 6],
    [1, 4, 7],
    [2, 5, 8],
    [0, 4, 8],
    [2, 4, 6]
];
let currentPlayer;

setup();

function setup () {
    board_el.classList.remove('turn-x', 'turn-o');

    for (let cell of cell_els) {
        cell.classList.remove('x', 'o');
        cell.addEventListener('click', fillCell, { once: true});
    }

    currentPlayer = Math.round(Math.random(0, 1)) == 1 ? 'x' : 'o';
    board_el.classList.add('turn-' + currentPlayer);
}

function fillCell () {
    this.classList.add(currentPlayer);

    if (checkForWin()) {
        const restart = confirm(currentPlayer.toUpperCase() + " is the winner! Restart?");

        if (restart) setup();
    } else if (checkforDraw()) {
        const restart = confirm("It's a draw! Restart?");

        if (restart) setup();
    } else {
        currentPlayer = currentPlayer == 'x' ? 'o' : 'x';
        board_el.classList.remove('turn-o', 'turn-x');
        board_el.classList.add('turn-' + currentPlayer);
    }
}

function checkForWin() {
    return combinations.some(combinations => {
        return combinations.every(c => {
            if (cell_els[c].classList.contains(currentPlayer)) {
                return true;
            }

            return false;
        });

    });
}

function checkforDraw () {
    return [...cell_els].every(c => {
        if (
            c.classList.contains('x') ||
            c.classList.contains('o')
        ) {
            return true;
        }

        return false;
    });
}



